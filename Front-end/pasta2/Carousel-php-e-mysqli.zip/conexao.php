<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "celke";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>
